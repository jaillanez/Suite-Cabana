--
-- PostgreSQL database dump
--

\restrict TcwtMDnIELzGLSZG0NDA2BD8cOxRmq6f8DFfi5iLAFcvjovaiRkW86nZYBG0ojV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: suite
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO suite;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: suite
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO suite;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: suite
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: canal_notificacion; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.canal_notificacion AS ENUM (
    'email',
    'whatsapp'
);


ALTER TYPE public.canal_notificacion OWNER TO suite;

--
-- Name: estado_notificacion; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.estado_notificacion AS ENUM (
    'pendiente',
    'enviada',
    'fallida',
    'descartada'
);


ALTER TYPE public.estado_notificacion OWNER TO suite;

--
-- Name: estado_publicacion; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.estado_publicacion AS ENUM (
    'borrador',
    'en_revision',
    'aprobada',
    'pausada',
    'rechazada'
);


ALTER TYPE public.estado_publicacion OWNER TO suite;

--
-- Name: estado_reserva; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.estado_reserva AS ENUM (
    'pendiente_pago',
    'pendiente_aprobacion',
    'confirmada',
    'cancelada',
    'completada',
    'en_reclamo'
);


ALTER TYPE public.estado_reserva OWNER TO suite;

--
-- Name: estado_reserva_externa; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.estado_reserva_externa AS ENUM (
    'confirmada',
    'por_revisar',
    'descartada'
);


ALTER TYPE public.estado_reserva_externa OWNER TO suite;

--
-- Name: modo_reserva; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.modo_reserva AS ENUM (
    'noches',
    'turno_cupo',
    'horario',
    'tramo',
    'horas'
);


ALTER TYPE public.modo_reserva OWNER TO suite;

--
-- Name: origen_bloqueo; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.origen_bloqueo AS ENUM (
    'manual',
    'ical',
    'retencion',
    'reserva',
    'externa'
);


ALTER TYPE public.origen_bloqueo OWNER TO suite;

--
-- Name: origen_reserva_externa; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.origen_reserva_externa AS ENUM (
    'particular',
    'correo'
);


ALTER TYPE public.origen_reserva_externa OWNER TO suite;

--
-- Name: quien_paga; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.quien_paga AS ENUM (
    'prestador',
    'viajero',
    'dividido'
);


ALTER TYPE public.quien_paga OWNER TO suite;

--
-- Name: tipo_pago; Type: TYPE; Schema: public; Owner: suite
--

CREATE TYPE public.tipo_pago AS ENUM (
    'total',
    'sena',
    'saldo',
    'reintegro'
);


ALTER TYPE public.tipo_pago OWNER TO suite;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: adicional; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.adicional (
    unidad_id uuid NOT NULL,
    nombre character varying(80) NOT NULL,
    descripcion character varying(200),
    precio numeric(14,2) NOT NULL,
    por_persona boolean NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.adicional OWNER TO suite;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO suite;

--
-- Name: bloqueo_fecha; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.bloqueo_fecha (
    unidad_id uuid NOT NULL,
    rango daterange NOT NULL,
    origen public.origen_bloqueo NOT NULL,
    activo boolean NOT NULL,
    vence_en timestamp with time zone,
    item_reserva_id uuid,
    calendario_externo_id uuid,
    nota character varying(200),
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    reserva_externa_id uuid
);


ALTER TABLE public.bloqueo_fecha OWNER TO suite;

--
-- Name: bloqueo_horario; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.bloqueo_horario (
    unidad_id uuid NOT NULL,
    rango tstzrange NOT NULL,
    origen public.origen_bloqueo NOT NULL,
    activo boolean NOT NULL,
    vence_en timestamp with time zone,
    item_reserva_id uuid,
    nota character varying(200),
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bloqueo_horario OWNER TO suite;

--
-- Name: calendario_externo; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.calendario_externo (
    unidad_id uuid NOT NULL,
    nombre character varying(60) NOT NULL,
    url character varying NOT NULL,
    ultima_sincronizacion timestamp with time zone,
    ultimo_error character varying,
    id uuid NOT NULL,
    plataforma character varying(30) DEFAULT 'otro'::character varying NOT NULL,
    ultimo_intento timestamp with time zone
);


ALTER TABLE public.calendario_externo OWNER TO suite;

--
-- Name: comision_aplicada; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.comision_aplicada (
    item_reserva_id uuid NOT NULL,
    regla_id uuid NOT NULL,
    regla_snapshot jsonb NOT NULL,
    base numeric(14,2) NOT NULL,
    comision_neta numeric(14,2) NOT NULL,
    iva numeric(14,2) NOT NULL,
    comision_total numeric(14,2) NOT NULL,
    cargo_viajero numeric(14,2) NOT NULL,
    descuento_prestador numeric(14,2) NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.comision_aplicada OWNER TO suite;

--
-- Name: comodidad; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.comodidad (
    codigo character varying(40) NOT NULL,
    nombre character varying(80) NOT NULL,
    icono character varying(40),
    id uuid NOT NULL
);


ALTER TABLE public.comodidad OWNER TO suite;

--
-- Name: comodidad_tipo_servicio; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.comodidad_tipo_servicio (
    comodidad_id uuid NOT NULL,
    tipo_servicio_id uuid NOT NULL
);


ALTER TABLE public.comodidad_tipo_servicio OWNER TO suite;

--
-- Name: cupo_tomado; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.cupo_tomado (
    salida_id uuid NOT NULL,
    personas smallint NOT NULL,
    origen public.origen_bloqueo NOT NULL,
    activo boolean NOT NULL,
    vence_en timestamp with time zone,
    item_reserva_id uuid,
    nota character varying(200),
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_cupo_tomado_personas_positivas CHECK ((personas > 0))
);


ALTER TABLE public.cupo_tomado OWNER TO suite;

--
-- Name: favorito; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.favorito (
    usuario_id uuid NOT NULL,
    publicacion_id uuid NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.favorito OWNER TO suite;

--
-- Name: foto; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.foto (
    publicacion_id uuid NOT NULL,
    url character varying NOT NULL,
    orden integer NOT NULL,
    descripcion character varying(200),
    id uuid NOT NULL
);


ALTER TABLE public.foto OWNER TO suite;

--
-- Name: franja_horaria; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.franja_horaria (
    unidad_id uuid NOT NULL,
    nombre character varying(80) NOT NULL,
    hora_inicio time without time zone NOT NULL,
    hora_fin time without time zone NOT NULL,
    precio numeric(14,2) NOT NULL,
    precios_dia_semana jsonb,
    activa boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.franja_horaria OWNER TO suite;

--
-- Name: item_reserva; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.item_reserva (
    reserva_id uuid NOT NULL,
    unidad_id uuid NOT NULL,
    prestador_id uuid NOT NULL,
    fecha_inicio date NOT NULL,
    fecha_fin date NOT NULL,
    adultos smallint NOT NULL,
    menores smallint NOT NULL,
    mascotas smallint NOT NULL,
    desglose jsonb NOT NULL,
    subtotal numeric(14,2) NOT NULL,
    id uuid NOT NULL,
    inicio_en timestamp with time zone,
    fin_en timestamp with time zone,
    politica_cancelacion jsonb,
    datos_servicio jsonb,
    CONSTRAINT ck_item_reserva_fechas_validas CHECK ((fecha_fin >= fecha_inicio))
);


ALTER TABLE public.item_reserva OWNER TO suite;

--
-- Name: localidad; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.localidad (
    provincia_id uuid NOT NULL,
    nombre character varying(120) NOT NULL,
    slug character varying(120) NOT NULL,
    ubicacion public.geography(Point,4326),
    id uuid NOT NULL
);


ALTER TABLE public.localidad OWNER TO suite;

--
-- Name: lugar_traslado; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.lugar_traslado (
    publicacion_id uuid NOT NULL,
    nombre character varying(120) NOT NULL,
    ubicacion public.geography(Point,4326),
    es_base boolean NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.lugar_traslado OWNER TO suite;

--
-- Name: notificacion; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.notificacion (
    usuario_id uuid,
    reserva_id uuid,
    canal public.canal_notificacion NOT NULL,
    evento character varying(40) NOT NULL,
    destino character varying(254) NOT NULL,
    asunto character varying(200),
    cuerpo character varying NOT NULL,
    estado public.estado_notificacion NOT NULL,
    intentos smallint NOT NULL,
    enviada_en timestamp with time zone,
    error character varying,
    datos jsonb,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notificacion OWNER TO suite;

--
-- Name: notificacion_pago; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.notificacion_pago (
    id_externo character varying(80) NOT NULL,
    topico character varying(40) NOT NULL,
    payload jsonb NOT NULL,
    procesada_en timestamp with time zone,
    error character varying,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    pasarela character varying(40) DEFAULT 'mercadopago'::character varying NOT NULL
);


ALTER TABLE public.notificacion_pago OWNER TO suite;

--
-- Name: pago; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.pago (
    reserva_id uuid NOT NULL,
    tipo public.tipo_pago NOT NULL,
    id_externo character varying(80),
    id_preferencia character varying(80),
    estado character varying(30) NOT NULL,
    monto numeric(14,2) NOT NULL,
    monto_prestador numeric(14,2) NOT NULL,
    monto_comision numeric(14,2) NOT NULL,
    iva_comision numeric(14,2) NOT NULL,
    datos jsonb,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    pasarela character varying(40) DEFAULT 'mercadopago'::character varying NOT NULL
);


ALTER TABLE public.pago OWNER TO suite;

--
-- Name: politica_cancelacion; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.politica_cancelacion (
    codigo character varying(30) NOT NULL,
    nombre character varying(80) NOT NULL,
    descripcion character varying,
    tramos jsonb NOT NULL,
    activa boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.politica_cancelacion OWNER TO suite;

--
-- Name: precio_pasajero; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.precio_pasajero (
    unidad_id uuid NOT NULL,
    nombre character varying(60) NOT NULL,
    descripcion character varying(200),
    edad_desde smallint,
    edad_hasta smallint,
    precio numeric(14,2) NOT NULL,
    ocupa_lugar boolean NOT NULL,
    orden smallint NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL,
    CONSTRAINT ck_precio_pasajero_edades CHECK (((edad_desde IS NULL) OR (edad_hasta IS NULL) OR (edad_hasta >= edad_desde))),
    CONSTRAINT ck_precio_pasajero_precio_no_negativo CHECK ((precio >= (0)::numeric))
);


ALTER TABLE public.precio_pasajero OWNER TO suite;

--
-- Name: prestador; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.prestador (
    usuario_id uuid NOT NULL,
    razon_social character varying(200) NOT NULL,
    cuit character varying(13),
    condicion_iva character varying(40),
    categoria character varying(40),
    fecha_alta date NOT NULL,
    verificado boolean NOT NULL,
    mp_user_id character varying(40),
    mp_access_token character varying,
    mp_refresh_token character varying,
    porcentaje_sena integer,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    es_demo boolean DEFAULT false NOT NULL,
    mp_cuenta character varying(200),
    CONSTRAINT ck_prestador_porcentaje_sena_rango CHECK (((porcentaje_sena IS NULL) OR ((porcentaje_sena >= 0) AND (porcentaje_sena <= 100))))
);


ALTER TABLE public.prestador OWNER TO suite;

--
-- Name: provincia; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.provincia (
    nombre character varying(80) NOT NULL,
    slug character varying(80) NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.provincia OWNER TO suite;

--
-- Name: publicacion; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.publicacion (
    prestador_id uuid NOT NULL,
    tipo_servicio_id uuid NOT NULL,
    subtipo_servicio_id uuid,
    titulo character varying(150) NOT NULL,
    slug character varying(170) NOT NULL,
    descripcion character varying NOT NULL,
    reglas_casa character varying,
    estado public.estado_publicacion NOT NULL,
    motivo_rechazo character varying,
    localidad_id uuid NOT NULL,
    zona_id uuid,
    direccion character varying(200),
    hora_ingreso time without time zone,
    hora_salida time without time zone,
    ubicacion public.geography(Point,4326),
    confirmacion_inmediata boolean NOT NULL,
    politica_cancelacion_id uuid,
    calificacion_promedio double precision,
    cantidad_resenas integer NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    es_demo boolean DEFAULT false NOT NULL,
    porcentaje_sena smallint,
    tramos_cancelacion jsonb,
    reintegro_si_no_sale smallint DEFAULT '100'::smallint NOT NULL,
    CONSTRAINT ck_publicacion_porcentaje_sena_rango CHECK (((porcentaje_sena IS NULL) OR ((porcentaje_sena >= 0) AND (porcentaje_sena <= 100)))),
    CONSTRAINT ck_publicacion_reintegro_si_no_sale_rango CHECK (((reintegro_si_no_sale >= 0) AND (reintegro_si_no_sale <= 100)))
);


ALTER TABLE public.publicacion OWNER TO suite;

--
-- Name: publicacion_comodidad; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.publicacion_comodidad (
    publicacion_id uuid NOT NULL,
    comodidad_id uuid NOT NULL
);


ALTER TABLE public.publicacion_comodidad OWNER TO suite;

--
-- Name: regla_comision; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.regla_comision (
    nombre character varying(120) NOT NULL,
    descripcion character varying,
    activa boolean NOT NULL,
    es_default boolean NOT NULL,
    prioridad integer NOT NULL,
    vigente_desde date,
    vigente_hasta date,
    tipo_servicio_id uuid,
    subtipo_servicio_id uuid,
    provincia_id uuid,
    localidad_id uuid,
    zona_id uuid,
    prestador_id uuid,
    publicacion_id uuid,
    servicio_desde date,
    servicio_hasta date,
    creacion_desde date,
    creacion_hasta date,
    monto_desde numeric(14,2),
    monto_hasta numeric(14,2),
    antiguedad_meses_desde smallint,
    antiguedad_meses_hasta smallint,
    categoria_prestador character varying(40),
    porcentaje numeric(7,4) NOT NULL,
    monto_fijo numeric(14,2) NOT NULL,
    minimo numeric(14,2),
    maximo numeric(14,2),
    quien_paga public.quien_paga NOT NULL,
    porcentaje_viajero numeric(7,4) NOT NULL,
    iva_incluido boolean NOT NULL,
    creado_por_id uuid,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.regla_comision OWNER TO suite;

--
-- Name: regla_comision_historial; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.regla_comision_historial (
    regla_id uuid NOT NULL,
    usuario_id uuid,
    accion character varying(20) NOT NULL,
    antes jsonb,
    despues jsonb,
    fecha timestamp with time zone DEFAULT now() NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.regla_comision_historial OWNER TO suite;

--
-- Name: resena; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.resena (
    reserva_id uuid NOT NULL,
    publicacion_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    puntaje smallint NOT NULL,
    comentario character varying,
    respuesta_prestador character varying,
    visible boolean NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_resena_puntaje_rango CHECK (((puntaje >= 1) AND (puntaje <= 5)))
);


ALTER TABLE public.resena OWNER TO suite;

--
-- Name: reserva; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.reserva (
    codigo character varying(12) NOT NULL,
    usuario_id uuid NOT NULL,
    estado public.estado_reserva NOT NULL,
    moneda character varying(3) NOT NULL,
    total numeric(14,2) NOT NULL,
    monto_sena numeric(14,2),
    vence_pago_en timestamp with time zone,
    vence_aprobacion_en timestamp with time zone,
    politica_cancelacion jsonb,
    cancelada_en timestamp with time zone,
    motivo_cancelacion character varying,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    acepto_terminos_en timestamp with time zone,
    version_terminos character varying(20)
);


ALTER TABLE public.reserva OWNER TO suite;

--
-- Name: reserva_externa; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.reserva_externa (
    prestador_id uuid NOT NULL,
    unidad_id uuid,
    origen public.origen_reserva_externa NOT NULL,
    estado public.estado_reserva_externa NOT NULL,
    plataforma character varying(30) NOT NULL,
    fecha_inicio date,
    fecha_fin date,
    huesped character varying(120),
    contacto character varying(120),
    personas smallint,
    monto numeric(14,2),
    codigo_externo character varying(80),
    nota character varying(400),
    faltantes jsonb,
    huella character varying(120),
    mensaje jsonb,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reserva_externa OWNER TO suite;

--
-- Name: salida_excursion; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.salida_excursion (
    unidad_id uuid NOT NULL,
    turno_id uuid,
    fecha date NOT NULL,
    inicio_en timestamp with time zone NOT NULL,
    fin_en timestamp with time zone NOT NULL,
    cupo smallint NOT NULL,
    ocupados smallint NOT NULL,
    suspendida boolean NOT NULL,
    motivo character varying(200),
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    minimo_personas smallint DEFAULT '1'::smallint NOT NULL,
    aviso_minimo_horas smallint DEFAULT '24'::smallint NOT NULL,
    sale_confirmada boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_salida_excursion_cupo_no_se_pasa CHECK (((ocupados >= 0) AND (ocupados <= cupo))),
    CONSTRAINT ck_salida_excursion_cupo_positivo CHECK ((cupo > 0)),
    CONSTRAINT ck_salida_excursion_horario_valido CHECK ((fin_en > inicio_en)),
    CONSTRAINT ck_salida_excursion_minimo_positivo CHECK ((minimo_personas >= 1))
);


ALTER TABLE public.salida_excursion OWNER TO suite;

--
-- Name: subtipo_servicio; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.subtipo_servicio (
    tipo_id uuid NOT NULL,
    codigo character varying(40) NOT NULL,
    nombre character varying(80) NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.subtipo_servicio OWNER TO suite;

--
-- Name: tarifa; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.tarifa (
    unidad_id uuid NOT NULL,
    nombre character varying(80) NOT NULL,
    fecha_desde date,
    fecha_hasta date,
    precio_noche numeric(14,2) NOT NULL,
    precios_dia_semana jsonb,
    estadia_minima smallint NOT NULL,
    estadia_maxima smallint,
    anticipacion_minima_dias smallint NOT NULL,
    prioridad integer NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.tarifa OWNER TO suite;

--
-- Name: tarifa_horaria; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.tarifa_horaria (
    unidad_id uuid NOT NULL,
    precio_hora numeric(14,2) NOT NULL,
    precios_dia_semana jsonb,
    horas_minimas smallint NOT NULL,
    hora_apertura time without time zone NOT NULL,
    hora_cierre time without time zone NOT NULL,
    recargo_nocturno_desde time without time zone,
    recargo_nocturno_porcentaje numeric(7,4) NOT NULL,
    activa boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.tarifa_horaria OWNER TO suite;

--
-- Name: tarifa_traslado; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.tarifa_traslado (
    unidad_id uuid NOT NULL,
    precio_km numeric(14,2),
    bajada numeric(14,2) NOT NULL,
    minimo numeric(14,2) NOT NULL,
    radio_km smallint,
    factor_ruta numeric(7,4) NOT NULL,
    velocidad_kmh smallint NOT NULL,
    recargo_nocturno_desde time without time zone,
    recargo_nocturno_hasta time without time zone,
    recargo_nocturno_porcentaje numeric(7,4) NOT NULL,
    vuelve_a_base boolean NOT NULL,
    anticipacion_minima_horas smallint NOT NULL,
    id uuid NOT NULL,
    CONSTRAINT ck_tarifa_traslado_anticipacion_rango CHECK (((anticipacion_minima_horas >= 0) AND (anticipacion_minima_horas <= 720))),
    CONSTRAINT ck_tarifa_traslado_factor_ruta_rango CHECK (((factor_ruta >= (1)::numeric) AND (factor_ruta <= (3)::numeric))),
    CONSTRAINT ck_tarifa_traslado_montos_no_negativos CHECK (((bajada >= (0)::numeric) AND (minimo >= (0)::numeric))),
    CONSTRAINT ck_tarifa_traslado_precio_km_positivo CHECK (((precio_km IS NULL) OR (precio_km > (0)::numeric))),
    CONSTRAINT ck_tarifa_traslado_radio_positivo CHECK (((radio_km IS NULL) OR (radio_km > 0))),
    CONSTRAINT ck_tarifa_traslado_recargo_rango CHECK (((recargo_nocturno_porcentaje >= (0)::numeric) AND (recargo_nocturno_porcentaje <= (200)::numeric))),
    CONSTRAINT ck_tarifa_traslado_velocidad_rango CHECK (((velocidad_kmh >= 10) AND (velocidad_kmh <= 150)))
);


ALTER TABLE public.tarifa_traslado OWNER TO suite;

--
-- Name: tipo_servicio; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.tipo_servicio (
    codigo character varying(40) NOT NULL,
    nombre character varying(80) NOT NULL,
    modo_reserva public.modo_reserva NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.tipo_servicio OWNER TO suite;

--
-- Name: tramo_traslado; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.tramo_traslado (
    unidad_id uuid NOT NULL,
    origen_id uuid NOT NULL,
    destino_id uuid NOT NULL,
    precio numeric(14,2) NOT NULL,
    por_persona boolean NOT NULL,
    duracion_minutos smallint NOT NULL,
    ambos_sentidos boolean NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL,
    CONSTRAINT ck_tramo_traslado_duracion_rango CHECK (((duracion_minutos >= 5) AND (duracion_minutos <= 2880))),
    CONSTRAINT ck_tramo_traslado_origen_distinto_destino CHECK ((origen_id <> destino_id)),
    CONSTRAINT ck_tramo_traslado_precio_positivo CHECK ((precio > (0)::numeric))
);


ALTER TABLE public.tramo_traslado OWNER TO suite;

--
-- Name: turno_excursion; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.turno_excursion (
    unidad_id uuid NOT NULL,
    nombre character varying(80) NOT NULL,
    dias_semana smallint[] NOT NULL,
    hora_inicio time without time zone NOT NULL,
    duracion_minutos integer NOT NULL,
    cupo smallint NOT NULL,
    desde date,
    hasta date,
    activo boolean NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    minimo_personas smallint DEFAULT '1'::smallint NOT NULL,
    aviso_minimo_horas smallint DEFAULT '24'::smallint NOT NULL,
    CONSTRAINT ck_turno_excursion_aviso_rango CHECK (((aviso_minimo_horas >= 0) AND (aviso_minimo_horas <= 720))),
    CONSTRAINT ck_turno_excursion_cupo_positivo CHECK ((cupo > 0)),
    CONSTRAINT ck_turno_excursion_dias_validos CHECK (((cardinality(dias_semana) > 0) AND (dias_semana <@ ARRAY[(0)::smallint, (1)::smallint, (2)::smallint, (3)::smallint, (4)::smallint, (5)::smallint, (6)::smallint]))),
    CONSTRAINT ck_turno_excursion_duracion_rango CHECK (((duracion_minutos >= 15) AND (duracion_minutos <= 20160))),
    CONSTRAINT ck_turno_excursion_minimo_rango CHECK (((minimo_personas >= 1) AND (minimo_personas <= cupo))),
    CONSTRAINT ck_turno_excursion_temporada CHECK (((hasta IS NULL) OR (desde IS NULL) OR (hasta >= desde)))
);


ALTER TABLE public.turno_excursion OWNER TO suite;

--
-- Name: unidad; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.unidad (
    publicacion_id uuid NOT NULL,
    nombre character varying(120) NOT NULL,
    capacidad smallint NOT NULL,
    capacidad_base smallint,
    activa boolean NOT NULL,
    cargo_limpieza numeric(14,2) NOT NULL,
    cargo_persona_extra numeric(14,2) NOT NULL,
    cargo_mascota numeric(14,2) NOT NULL,
    descuento_semanal numeric(7,4) NOT NULL,
    descuento_mensual numeric(7,4) NOT NULL,
    ical_export_token uuid NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    capacidad_sentados smallint,
    preparacion_minutos smallint DEFAULT '0'::smallint NOT NULL,
    equipaje smallint
);


ALTER TABLE public.unidad OWNER TO suite;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.usuario (
    email character varying(254) NOT NULL,
    hash_password character varying,
    google_sub character varying,
    nombre character varying(120) NOT NULL,
    apellido character varying(120) NOT NULL,
    telefono character varying(30),
    email_verificado boolean NOT NULL,
    telefono_verificado boolean NOT NULL,
    es_viajero boolean NOT NULL,
    es_prestador boolean NOT NULL,
    es_operador boolean NOT NULL,
    activo boolean NOT NULL,
    id uuid NOT NULL,
    creado_en timestamp with time zone DEFAULT now() NOT NULL,
    actualizado_en timestamp with time zone DEFAULT now() NOT NULL,
    acepto_terminos_en timestamp with time zone,
    version_terminos character varying(20)
);


ALTER TABLE public.usuario OWNER TO suite;

--
-- Name: zona; Type: TABLE; Schema: public; Owner: suite
--

CREATE TABLE public.zona (
    localidad_id uuid NOT NULL,
    nombre character varying(120) NOT NULL,
    id uuid NOT NULL
);


ALTER TABLE public.zona OWNER TO suite;

--
-- Data for Name: adicional; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.adicional (unidad_id, nombre, descripcion, precio, por_persona, activo, id) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.alembic_version (version_num) FROM stdin;
0017
\.


--
-- Data for Name: bloqueo_fecha; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.bloqueo_fecha (unidad_id, rango, origen, activo, vence_en, item_reserva_id, calendario_externo_id, nota, id, creado_en, actualizado_en, reserva_externa_id) FROM stdin;
\.


--
-- Data for Name: bloqueo_horario; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.bloqueo_horario (unidad_id, rango, origen, activo, vence_en, item_reserva_id, nota, id, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: calendario_externo; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.calendario_externo (unidad_id, nombre, url, ultima_sincronizacion, ultimo_error, id, plataforma, ultimo_intento) FROM stdin;
\.


--
-- Data for Name: comision_aplicada; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.comision_aplicada (item_reserva_id, regla_id, regla_snapshot, base, comision_neta, iva, comision_total, cargo_viajero, descuento_prestador, id) FROM stdin;
\.


--
-- Data for Name: comodidad; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.comodidad (codigo, nombre, icono, id) FROM stdin;
wifi	WiFi	wifi	03d788e6-9b23-4bd7-9670-f513ada0a740
pileta	Pileta	pileta	ef09ef80-358b-4926-a91c-92655144897e
mascotas	Acepta mascotas	mascota	d4634eb1-f6a2-4b6c-aa63-9db27544a9fb
cochera	Cochera	auto	cc9dc39d-be6f-4b28-ad63-a3510808a360
parrilla	Parrilla	parrilla	478acbe4-e28c-4d46-9be3-abcadb2476cb
aire	Aire acondicionado	aire	27502cca-6001-4623-b010-9a6ba0e96367
calefaccion	Calefacción	calefaccion	97d54857-dbe5-40bb-922f-f6dba951b9a6
desayuno	Desayuno incluido	desayuno	036730f1-b26a-41c6-910c-6fe290daecaf
lavarropas	Lavarropas	lavarropas	49856742-34e1-484f-b985-72cffa67d2dc
tv	TV por cable	tv	e2d5f2a2-c8a4-4dd1-a3b5-6db56f350728
ropa_blanca	Ropa blanca incluida	cama	8e1c5eab-5af3-4bea-8fe4-70fdfd24f0e2
accesible	Accesible en silla de ruedas	accesible	4f2f6e64-dda5-48fc-bd1a-6facdf1d05ab
salon	Salón de eventos	salon	a3570293-7a02-4248-ac6e-65ab32b7e6c1
quincho	Quincho	quincho	d350c05d-5019-4395-b142-49394615078b
estacionamiento	Estacionamiento	auto	708246df-5176-487c-87ce-5e4157e993c7
sonido	Equipo de sonido	sonido	35283dc6-ae98-47da-b75d-0e52702b24d5
pista	Pista de baile	pista	b9e46e1f-fd6f-4807-b881-d98cb67f2efe
mesas_sillas	Mesas y sillas	mesa	7669c3c8-0038-4912-98fa-c7f57ad1242a
cocina	Cocina equipada	cocina	383ac99d-8519-4617-87ba-c8d0dd1d2f67
vajilla	Vajilla	vajilla	c3658ed9-2f7c-4ed7-a781-94678d55c43f
escenario	Escenario	escenario	a77b6157-43a9-48c0-bc40-2b2dc3305e3d
proyector	Proyector y pantalla	proyector	be07e6c1-6af2-480a-823c-7bc1eaf6308b
grupo_electrogeno	Grupo electrógeno	energia	8a6487fd-90aa-4867-bc89-3b4ec681d7c7
juegos_infantiles	Juegos infantiles	juegos	c282c6ae-ba49-4e88-b096-0045d5d3d6c9
banos_accesibles	Baños accesibles	accesible	b31fe59e-fa07-4daa-a4bc-16ff59dd3849
guia	Guía incluido	guia	9d66bee1-9b1f-4687-9f30-d6f8e68a7106
traslado_incluido	Traslado incluido	auto	080a590c-7050-4a11-9564-78ef4866d727
equipo	Equipo incluido	equipo	7fe9e686-b4e1-4f79-87a2-d163b1f763af
refrigerio	Refrigerio incluido	desayuno	2d91585d-92ba-4e37-97fd-87801b6c1c3a
apto_chicos	Apto para chicos	juegos	8ff74751-1c88-44bc-b4a8-26cb5fb6e99a
mascotas_excursion	Se puede ir con mascota	mascota	f4b76de6-8f9d-4359-93f7-0b8598ffb2ae
cartel_bienvenida	Te esperan con cartel	guia	6ebd606f-2218-4736-8265-34bcdcd059be
espera_demora	Esperan si el vuelo se demora	reloj	749614cb-40f7-41ac-be30-c1f2e85a0ab2
silla_bebe	Silla para bebé	juegos	fa32aaea-b070-4f79-9d74-71d0c35ca8de
mascotas_traslado	Viaja con mascota	mascota	8a2582fa-a6f4-47ec-b123-d6972736e194
factura	Emite factura	documento	8c60f211-bc8a-4e5b-bb49-11f287cffe44
\.


--
-- Data for Name: comodidad_tipo_servicio; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.comodidad_tipo_servicio (comodidad_id, tipo_servicio_id) FROM stdin;
03d788e6-9b23-4bd7-9670-f513ada0a740	e5366df0-295e-426a-9e01-6c3fc2b15121
ef09ef80-358b-4926-a91c-92655144897e	e5366df0-295e-426a-9e01-6c3fc2b15121
d4634eb1-f6a2-4b6c-aa63-9db27544a9fb	e5366df0-295e-426a-9e01-6c3fc2b15121
cc9dc39d-be6f-4b28-ad63-a3510808a360	e5366df0-295e-426a-9e01-6c3fc2b15121
478acbe4-e28c-4d46-9be3-abcadb2476cb	e5366df0-295e-426a-9e01-6c3fc2b15121
27502cca-6001-4623-b010-9a6ba0e96367	e5366df0-295e-426a-9e01-6c3fc2b15121
97d54857-dbe5-40bb-922f-f6dba951b9a6	e5366df0-295e-426a-9e01-6c3fc2b15121
036730f1-b26a-41c6-910c-6fe290daecaf	e5366df0-295e-426a-9e01-6c3fc2b15121
49856742-34e1-484f-b985-72cffa67d2dc	e5366df0-295e-426a-9e01-6c3fc2b15121
e2d5f2a2-c8a4-4dd1-a3b5-6db56f350728	e5366df0-295e-426a-9e01-6c3fc2b15121
8e1c5eab-5af3-4bea-8fe4-70fdfd24f0e2	e5366df0-295e-426a-9e01-6c3fc2b15121
4f2f6e64-dda5-48fc-bd1a-6facdf1d05ab	e5366df0-295e-426a-9e01-6c3fc2b15121
a3570293-7a02-4248-ac6e-65ab32b7e6c1	e5366df0-295e-426a-9e01-6c3fc2b15121
d350c05d-5019-4395-b142-49394615078b	e5366df0-295e-426a-9e01-6c3fc2b15121
be07e6c1-6af2-480a-823c-7bc1eaf6308b	2a0cfafc-cda4-435f-945c-5f07010fc118
383ac99d-8519-4617-87ba-c8d0dd1d2f67	2a0cfafc-cda4-435f-945c-5f07010fc118
708246df-5176-487c-87ce-5e4157e993c7	2a0cfafc-cda4-435f-945c-5f07010fc118
27502cca-6001-4623-b010-9a6ba0e96367	2a0cfafc-cda4-435f-945c-5f07010fc118
8a6487fd-90aa-4867-bc89-3b4ec681d7c7	2a0cfafc-cda4-435f-945c-5f07010fc118
03d788e6-9b23-4bd7-9670-f513ada0a740	2a0cfafc-cda4-435f-945c-5f07010fc118
4f2f6e64-dda5-48fc-bd1a-6facdf1d05ab	2a0cfafc-cda4-435f-945c-5f07010fc118
97d54857-dbe5-40bb-922f-f6dba951b9a6	2a0cfafc-cda4-435f-945c-5f07010fc118
c282c6ae-ba49-4e88-b096-0045d5d3d6c9	2a0cfafc-cda4-435f-945c-5f07010fc118
ef09ef80-358b-4926-a91c-92655144897e	2a0cfafc-cda4-435f-945c-5f07010fc118
c3658ed9-2f7c-4ed7-a781-94678d55c43f	2a0cfafc-cda4-435f-945c-5f07010fc118
b9e46e1f-fd6f-4807-b881-d98cb67f2efe	2a0cfafc-cda4-435f-945c-5f07010fc118
b31fe59e-fa07-4daa-a4bc-16ff59dd3849	2a0cfafc-cda4-435f-945c-5f07010fc118
7669c3c8-0038-4912-98fa-c7f57ad1242a	2a0cfafc-cda4-435f-945c-5f07010fc118
a77b6157-43a9-48c0-bc40-2b2dc3305e3d	2a0cfafc-cda4-435f-945c-5f07010fc118
35283dc6-ae98-47da-b75d-0e52702b24d5	2a0cfafc-cda4-435f-945c-5f07010fc118
478acbe4-e28c-4d46-9be3-abcadb2476cb	2a0cfafc-cda4-435f-945c-5f07010fc118
8ff74751-1c88-44bc-b4a8-26cb5fb6e99a	01f97704-06af-499b-bbc0-ded5f81a541e
4f2f6e64-dda5-48fc-bd1a-6facdf1d05ab	01f97704-06af-499b-bbc0-ded5f81a541e
080a590c-7050-4a11-9564-78ef4866d727	01f97704-06af-499b-bbc0-ded5f81a541e
9d66bee1-9b1f-4687-9f30-d6f8e68a7106	01f97704-06af-499b-bbc0-ded5f81a541e
f4b76de6-8f9d-4359-93f7-0b8598ffb2ae	01f97704-06af-499b-bbc0-ded5f81a541e
7fe9e686-b4e1-4f79-87a2-d163b1f763af	01f97704-06af-499b-bbc0-ded5f81a541e
2d91585d-92ba-4e37-97fd-87801b6c1c3a	01f97704-06af-499b-bbc0-ded5f81a541e
fa32aaea-b070-4f79-9d74-71d0c35ca8de	309f8bcf-5a35-47ab-a09f-616c34763793
27502cca-6001-4623-b010-9a6ba0e96367	309f8bcf-5a35-47ab-a09f-616c34763793
8a2582fa-a6f4-47ec-b123-d6972736e194	309f8bcf-5a35-47ab-a09f-616c34763793
8c60f211-bc8a-4e5b-bb49-11f287cffe44	309f8bcf-5a35-47ab-a09f-616c34763793
4f2f6e64-dda5-48fc-bd1a-6facdf1d05ab	309f8bcf-5a35-47ab-a09f-616c34763793
749614cb-40f7-41ac-be30-c1f2e85a0ab2	309f8bcf-5a35-47ab-a09f-616c34763793
6ebd606f-2218-4736-8265-34bcdcd059be	309f8bcf-5a35-47ab-a09f-616c34763793
\.


--
-- Data for Name: cupo_tomado; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.cupo_tomado (salida_id, personas, origen, activo, vence_en, item_reserva_id, nota, id, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: favorito; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.favorito (usuario_id, publicacion_id, id, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: foto; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.foto (publicacion_id, url, orden, descripcion, id) FROM stdin;
\.


--
-- Data for Name: franja_horaria; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.franja_horaria (unidad_id, nombre, hora_inicio, hora_fin, precio, precios_dia_semana, activa, id) FROM stdin;
\.


--
-- Data for Name: item_reserva; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.item_reserva (reserva_id, unidad_id, prestador_id, fecha_inicio, fecha_fin, adultos, menores, mascotas, desglose, subtotal, id, inicio_en, fin_en, politica_cancelacion, datos_servicio) FROM stdin;
\.


--
-- Data for Name: localidad; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.localidad (provincia_id, nombre, slug, ubicacion, id) FROM stdin;
2a66686c-89d2-427e-88d3-34664c7198a2	Rivadavia	rivadavia	0101000020E61000006FF085C9542551C0F1F44A5986883FC0	4d474921-8e18-489c-b537-0a7164b9d7e4
2a66686c-89d2-427e-88d3-34664c7198a2	Capital	capital-san-juan	0101000020E6100000C364AA60542251C09A99999999893FC0	893a1837-21e9-4a8a-b071-6ffa1d41a090
2a66686c-89d2-427e-88d3-34664c7198a2	Rawson	rawson	0101000020E61000003CBD5296212251C0BEC1172653953FC0	70426ae5-157a-4f56-9002-217e7e01b4c2
2a66686c-89d2-427e-88d3-34664c7198a2	Santa Lucía	santa-lucia	0101000020E6100000098A1F63EE1E51C0F1F44A5986883FC0	76454ee5-d666-4ae7-b09b-59372a20c211
2a66686c-89d2-427e-88d3-34664c7198a2	Chimbas	chimbas	0101000020E61000003CBD5296212251C024287E8CB97B3FC0	a2e49770-611c-40f7-a75e-58e95801a11e
2a66686c-89d2-427e-88d3-34664c7198a2	Pocito	pocito	0101000020E61000006FF085C9542551C0423EE8D9ACAA3FC0	7ec38a8b-5953-4a2f-b132-6ee8d3ac3434
2a66686c-89d2-427e-88d3-34664c7198a2	Albardón	albardon	0101000020E6100000098A1F63EE1E51C0575BB1BFEC6E3FC0	ff6ad213-3ed6-45f4-ab3a-8a2077b61589
2a66686c-89d2-427e-88d3-34664c7198a2	Caucete	caucete	0101000020E61000003CBD5296211251C06666666666A63FC0	29252016-0527-4a46-9a1c-9decda5b2e21
2a66686c-89d2-427e-88d3-34664c7198a2	9 de Julio	nueve-de-julio	0101000020E61000005DDC4603781751C0F1F44A5986883FC0	493559b0-0e05-4b0e-8e2c-4ff04250f236
2a66686c-89d2-427e-88d3-34664c7198a2	Angaco	angaco	0101000020E6100000A323B9FC871851C0575BB1BFEC6E3FC0	8695c4e4-d4fb-4c5a-af47-4e7ef6f996b5
2a66686c-89d2-427e-88d3-34664c7198a2	San Martín	san-martin	0101000020E61000006FF085C9541551C0575BB1BFEC6E3FC0	827222ce-fc7e-4bda-b67c-193e87a2fdae
2a66686c-89d2-427e-88d3-34664c7198a2	25 de Mayo	veinticinco-de-mayo	0101000020E61000003CBD5296211251C00F0BB5A679B73FC0	ac635798-6f76-47f0-8cef-251c0fc07595
2a66686c-89d2-427e-88d3-34664c7198a2	Sarmiento	sarmiento	0101000020E6100000910F7A36AB1A51C024287E8CB9FB3FC0	3036738b-ca40-4ec9-a3ff-7d0b36ce42c7
2a66686c-89d2-427e-88d3-34664c7198a2	Zonda	zonda	0101000020E6100000CDCCCCCCCC2C51C0F1F44A5986883FC0	07763fc9-0c72-427c-ac79-eba86b50d1ac
2a66686c-89d2-427e-88d3-34664c7198a2	Ullum	ullum	0101000020E6100000910F7A36AB2A51C03333333333733FC0	a67ba024-b2bb-4ad5-83d3-374e54721d0b
2a66686c-89d2-427e-88d3-34664c7198a2	Calingasta	calingasta	0101000020E6100000910F7A36AB5A51C0BEC1172653553FC0	2f3e049a-e572-4491-a7a0-053f843f1fae
2a66686c-89d2-427e-88d3-34664c7198a2	Iglesia	iglesia	0101000020E6100000A323B9FC874851C00F0BB5A679373EC0	2aa010ef-d042-4969-93fa-36f0ea1924ca
2a66686c-89d2-427e-88d3-34664c7198a2	Valle Fértil	valle-fertil	0101000020E6100000C442AD69DEDD50C08A8EE4F21FA23EC0	1b081dfc-0ea1-41cf-ab99-6a7be32c7571
2a66686c-89d2-427e-88d3-34664c7198a2	Jáchal	jachal	0101000020E610000000000000003051C024287E8CB93B3EC0	180a42ae-c292-4c69-b4aa-4e7cfc02589b
\.


--
-- Data for Name: lugar_traslado; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.lugar_traslado (publicacion_id, nombre, ubicacion, es_base, activo, id) FROM stdin;
\.


--
-- Data for Name: notificacion; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.notificacion (usuario_id, reserva_id, canal, evento, destino, asunto, cuerpo, estado, intentos, enviada_en, error, datos, id, creado_en, actualizado_en) FROM stdin;
feecbaf5-7297-455c-9349-d1ef445a37f2	\N	email	verificacion_email	virginialauratello@gmail.com	Confirmá tu correo	(enlace de verificación, no se guarda)	enviada	0	2026-11-28 10:50:17.084278+00	\N	{}	0c4fba7e-7b52-46f8-97b2-766c84027578	2026-11-28 10:50:14.998414+00	2026-11-28 10:50:14.998414+00
\.


--
-- Data for Name: notificacion_pago; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.notificacion_pago (id_externo, topico, payload, procesada_en, error, id, creado_en, actualizado_en, pasarela) FROM stdin;
\.


--
-- Data for Name: pago; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.pago (reserva_id, tipo, id_externo, id_preferencia, estado, monto, monto_prestador, monto_comision, iva_comision, datos, id, creado_en, actualizado_en, pasarela) FROM stdin;
\.


--
-- Data for Name: politica_cancelacion; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.politica_cancelacion (codigo, nombre, descripcion, tramos, activa, id) FROM stdin;
flexible	Flexible	Provisoria: los porcentajes y plazos definitivos están pendientes (docs/01 §9).	[{"dias_antes": 1, "porcentaje_reintegro": 100}, {"dias_antes": 0, "porcentaje_reintegro": 50}]	t	b54a7453-ede1-464f-af12-353dfc05643e
moderada	Moderada	Provisoria: los porcentajes y plazos definitivos están pendientes (docs/01 §9).	[{"dias_antes": 7, "porcentaje_reintegro": 100}, {"dias_antes": 2, "porcentaje_reintegro": 50}]	t	7dc8d786-ba52-412d-a94f-880698391887
estricta	Estricta	Provisoria: los porcentajes y plazos definitivos están pendientes (docs/01 §9).	[{"dias_antes": 30, "porcentaje_reintegro": 100}, {"dias_antes": 14, "porcentaje_reintegro": 50}]	t	4e4b4d73-baa9-4400-8351-9484a59a615d
eventos	Eventos	Hasta 30 días antes se devuelve el 90 % de lo pagado; hasta 15 días antes, el 50 %; después, nada.	[{"dias_antes": 30, "porcentaje_reintegro": 90}, {"dias_antes": 15, "porcentaje_reintegro": 50}]	t	e1b15395-6928-4059-a0ad-4f35e99ec444
\.


--
-- Data for Name: precio_pasajero; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.precio_pasajero (unidad_id, nombre, descripcion, edad_desde, edad_hasta, precio, ocupa_lugar, orden, activo, id) FROM stdin;
\.


--
-- Data for Name: prestador; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.prestador (usuario_id, razon_social, cuit, condicion_iva, categoria, fecha_alta, verificado, mp_user_id, mp_access_token, mp_refresh_token, porcentaje_sena, id, creado_en, actualizado_en, es_demo, mp_cuenta) FROM stdin;
feecbaf5-7297-455c-9349-d1ef445a37f2	Quinta los Buhos	27239778343	monotributo	\N	2026-11-28	f	\N	\N	\N	\N	584a7789-fd85-47a7-9138-bc0f89c98e86	2026-11-28 10:54:37.579384+00	2026-11-28 10:54:37.579384+00	f	\N
\.


--
-- Data for Name: provincia; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.provincia (nombre, slug, id) FROM stdin;
Buenos Aires	buenos-aires	5309c820-2513-4401-9c2a-0e3773a47e92
Catamarca	catamarca	1b19fbca-89aa-4ff0-85b1-2d41793e9b7c
Chaco	chaco	9ec17911-215e-445c-838c-ef025e1de969
Chubut	chubut	22de7495-aa9d-4c2f-86b2-5086fa8ada24
Ciudad Autónoma de Buenos Aires	caba	f4c0ddb8-d9eb-4227-8680-81dd3c6615d1
Córdoba	cordoba	eeea77c4-b2d8-4a25-b15d-e107940c334b
Corrientes	corrientes	7b153b24-f989-41a0-b6d3-5cf8d9935dff
Entre Ríos	entre-rios	5c1a30f9-5565-4b0c-a7eb-f9a39a9266a9
Formosa	formosa	274f9b65-ca2f-48ca-a7f2-3c7757469dbd
Jujuy	jujuy	ef7a8b29-8fde-441e-a923-58fda2fcedba
La Pampa	la-pampa	02a1871c-94df-48ad-b1d4-0df06661c2f1
La Rioja	la-rioja	7b8a69a9-dd15-404d-892e-8b1a30c95f2d
Mendoza	mendoza	942147b9-aab6-4286-ae3c-2e9b4af303ca
Misiones	misiones	05fe2323-2e5e-4d14-bda2-fda8c95ed217
Neuquén	neuquen	7d7770d5-e8ee-4f1d-a218-3550b58e7a16
Río Negro	rio-negro	3780066b-bf60-4308-9206-dacd25c9c98f
Salta	salta	f665b7ba-98db-4999-b915-55568db805ec
San Juan	san-juan	2a66686c-89d2-427e-88d3-34664c7198a2
San Luis	san-luis	30e06a8f-d07a-4be3-9a6a-83f2a3b74bac
Santa Cruz	santa-cruz	2cf2cfc9-f1d1-4489-870e-08233862896b
Santa Fe	santa-fe	54089d36-8ceb-4941-a3e3-659acce49e34
Santiago del Estero	santiago-del-estero	098c0b6c-757e-4309-abe5-7d6dd9c7ab34
Tierra del Fuego	tierra-del-fuego	27b1e585-f15a-48f6-86e9-f182d4f9f039
Tucumán	tucuman	5b040a12-bd36-4b27-baf8-720eb72028db
\.


--
-- Data for Name: publicacion; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.publicacion (prestador_id, tipo_servicio_id, subtipo_servicio_id, titulo, slug, descripcion, reglas_casa, estado, motivo_rechazo, localidad_id, zona_id, direccion, hora_ingreso, hora_salida, ubicacion, confirmacion_inmediata, politica_cancelacion_id, calificacion_promedio, cantidad_resenas, id, creado_en, actualizado_en, es_demo, porcentaje_sena, tramos_cancelacion, reintegro_si_no_sale) FROM stdin;
584a7789-fd85-47a7-9138-bc0f89c98e86	e5366df0-295e-426a-9e01-6c3fc2b15121	7e08e007-0321-46d7-8401-dfba1bbec16a	Quinta los buhos	quinta-los-buhos-rawson	🌿 Quinta Los Búhos – Un rincón para desconectar y disfrutar 🦉\nHay lugares que se visitan y otros que se quedan en el corazón. ❤️\nQuinta Los Búhos es ese refugio especial donde la tranquilidad, la naturaleza y los momentos compartidos se convierten en recuerdos inolvidables.\nUbicada en Médano de Oro, San Juan, nuestra quinta te invita a disfrutar de un entorno lleno de verde, aire puro y la calidez de un espacio pensado para descansar y sentirte como en casa.\n🌳 Relajate rodeado de naturaleza.\n💦 Disfrutá de la pileta y de los días de sol.\n🔥 Aprovechá el quincho y el parrillero para disfrutar de una rica comida en buena compañía.\n✨ Ideal para una escapada en pareja, unos días de descanso en familia o simplemente para desconectarte de la rutina.\nEn Quinta Los Búhos queremos que cada huésped se lleve algo más que una estadía: la sensación de haber encontrado un lugar al que siempre dan ganas de volver.\n📍 Calle América y Calle 4, Médano de Oro, San Juan.\n❤️ Quinta Los Búhos: vení a descansar, disfrutar y crear tus mejores recuerdos.	NORMAS DE LA CABAÑA\n\nPara que todos puedan disfrutar de una buena estadía y mantener una buena convivencia con nuestros vecinos, les pedimos respetar las siguientes normas:\n\n* La cabaña es de uso exclusivo para la cantidad de personas informadas en la reserva. No está permitido recibir invitados o personas adicionales sin autorización previa del propietario.\n\n* No se permiten fiestas, eventos ni reuniones con personas ajenas a la reserva.\n\n* Les pedimos cuidar la cabaña, el mobiliario y todas sus instalaciones. Cualquier rotura, daño o faltante ocasionado durante la estadía será responsabilidad de quien realizó la reserva.\n\n* Música y ruidos: debido a que estamos en una zona muy tranquila y el sonido se escucha a gran distancia, de domingo a viernes se permite música únicamente hasta las 23:00 hs. Los sábados, excepcionalmente, hasta las 03:00 hs, siempre manteniendo un volumen razonable y respetando a los vecinos.\n\n* No está permitido realizar un uso indebido de las instalaciones ni desarrollar actividades diferentes a las propias de una estadía.\n\nAgradecemos mucho que respeten estas normas. Nuestro objetivo es que disfruten de la cabaña y que podamos mantener un ambiente tranquilo y agradable para todos.\n\nAl confirmar la reserva, se entiende que estas normas son conocidas y aceptadas por los huéspedes.	borrador	\N	70426ae5-157a-4f56-9002-217e7e01b4c2	\N	calle america y 4 medano de oro	12:00:00	10:00:00	\N	t	7dc8d786-ba52-412d-a94f-880698391887	\N	0	6cc1107f-eb82-4423-8a00-06444f6c399d	2026-11-28 10:56:22.997212+00	2026-11-28 11:06:22.591464+00	f	\N	\N	100
584a7789-fd85-47a7-9138-bc0f89c98e86	e5366df0-295e-426a-9e01-6c3fc2b15121	7e08e007-0321-46d7-8401-dfba1bbec16a	Quinta los buhos	quinta-los-buhos-rawson-2	🌿 Quinta Los Búhos – Un rincón para desconectar y disfrutar 🦉\n\nHay lugares que se visitan y otros que se quedan en el corazón. ❤️\n\nQuinta Los Búhos es ese refugio especial donde la tranquilidad, la naturaleza y los momentos compartidos se convierten en recuerdos inolvidables.\n\nUbicada en Médano de Oro, San Juan, nuestra quinta te invita a disfrutar de un entorno lleno de verde, aire puro y la calidez de un espacio pensado para descansar y sentirte como en casa.\n\n🌳 Relajate rodeado de naturaleza.\n\n💦 Disfrutá de la pileta y de los días de sol.\n\n🔥 Aprovechá el quincho y el parrillero para disfrutar de una rica comida en buena compañía.\n\n✨ Ideal para una escapada en pareja, unos días de descanso en familia o simplemente para desconectarte de la rutina.\n\nEn Quinta Los Búhos queremos que cada huésped se lleve algo más que una estadía: la sensación de haber encontrado un lugar al que siempre dan ganas de volver.\n\n📍 Calle América y Calle 4, Médano de Oro, San Juan.\n\n❤️ Quinta Los Búhos: vení a descansar, disfrutar y crear tus mejores recuerdos.	NORMAS DE LA CABAÑA\n\nPara que todos puedan disfrutar de una buena estadía y mantener una buena convivencia con nuestros vecinos, les pedimos respetar las siguientes normas:\n\n* La cabaña es de uso exclusivo para la cantidad de personas informadas en la reserva. No está permitido recibir invitados o personas adicionales sin autorización previa del propietario.\n\n* No se permiten fiestas, eventos ni reuniones con personas ajenas a la reserva.\n\n* Les pedimos cuidar la cabaña, el mobiliario y todas sus instalaciones. Cualquier rotura, daño o faltante ocasionado durante la estadía será responsabilidad de quien realizó la reserva.\n\n* Música y ruidos: debido a que estamos en una zona muy tranquila y el sonido se escucha a gran distancia, de domingo a viernes se permite música únicamente hasta las 23:00 hs. Los sábados, excepcionalmente, hasta las 03:00 hs, siempre manteniendo un volumen razonable y respetando a los vecinos.\n\n* No está permitido realizar un uso indebido de las instalaciones ni desarrollar actividades diferentes a las propias de una estadía.\n\nAgradecemos mucho que respeten estas normas. Nuestro objetivo es que disfruten de la cabaña y que podamos mantener un ambiente tranquilo y agradable para todos.\n\nAl confirmar la reserva, se entiende que estas normas son conocidas y aceptadas por los huéspedes.	borrador	\N	70426ae5-157a-4f56-9002-217e7e01b4c2	\N	calle america y 4 medano de oro	\N	\N	0101000020E610000018096D39972251C0DC2E34D7699C3FC0	t	\N	\N	0	b9a72d68-1139-43d5-8f9b-3531bff3ecdf	2026-11-28 11:16:57.663479+00	2026-11-28 11:18:53.943795+00	f	\N	\N	100
\.


--
-- Data for Name: publicacion_comodidad; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.publicacion_comodidad (publicacion_id, comodidad_id) FROM stdin;
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	d4634eb1-f6a2-4b6c-aa63-9db27544a9fb
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	27502cca-6001-4623-b010-9a6ba0e96367
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	97d54857-dbe5-40bb-922f-f6dba951b9a6
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	cc9dc39d-be6f-4b28-ad63-a3510808a360
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	478acbe4-e28c-4d46-9be3-abcadb2476cb
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	ef09ef80-358b-4926-a91c-92655144897e
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	d350c05d-5019-4395-b142-49394615078b
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	8e1c5eab-5af3-4bea-8fe4-70fdfd24f0e2
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	03d788e6-9b23-4bd7-9670-f513ada0a740
b9a72d68-1139-43d5-8f9b-3531bff3ecdf	a3570293-7a02-4248-ac6e-65ab32b7e6c1
\.


--
-- Data for Name: regla_comision; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.regla_comision (nombre, descripcion, activa, es_default, prioridad, vigente_desde, vigente_hasta, tipo_servicio_id, subtipo_servicio_id, provincia_id, localidad_id, zona_id, prestador_id, publicacion_id, servicio_desde, servicio_hasta, creacion_desde, creacion_hasta, monto_desde, monto_hasta, antiguedad_meses_desde, antiguedad_meses_hasta, categoria_prestador, porcentaje, monto_fijo, minimo, maximo, quien_paga, porcentaje_viajero, iva_incluido, creado_por_id, id, creado_en, actualizado_en) FROM stdin;
Comisión general	Regla por defecto: se aplica cuando ninguna regla más específica coincide. Cambiar `quien_paga` decide si el cargo lo absorbe el prestador, lo paga el viajero como cargo de servicio, o se reparte.	t	t	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	10.0000	0.00	\N	\N	prestador	0.0000	f	\N	62f7d697-23f8-4e26-a962-efe02a2c5dda	2026-11-20 14:34:03.403619+00	2026-11-20 14:34:03.403619+00
\.


--
-- Data for Name: regla_comision_historial; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.regla_comision_historial (regla_id, usuario_id, accion, antes, despues, fecha, id) FROM stdin;
\.


--
-- Data for Name: resena; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.resena (reserva_id, publicacion_id, usuario_id, puntaje, comentario, respuesta_prestador, visible, id, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: reserva; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.reserva (codigo, usuario_id, estado, moneda, total, monto_sena, vence_pago_en, vence_aprobacion_en, politica_cancelacion, cancelada_en, motivo_cancelacion, id, creado_en, actualizado_en, acepto_terminos_en, version_terminos) FROM stdin;
\.


--
-- Data for Name: reserva_externa; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.reserva_externa (prestador_id, unidad_id, origen, estado, plataforma, fecha_inicio, fecha_fin, huesped, contacto, personas, monto, codigo_externo, nota, faltantes, huella, mensaje, id, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: salida_excursion; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.salida_excursion (unidad_id, turno_id, fecha, inicio_en, fin_en, cupo, ocupados, suspendida, motivo, id, creado_en, actualizado_en, minimo_personas, aviso_minimo_horas, sale_confirmada) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: subtipo_servicio; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.subtipo_servicio (tipo_id, codigo, nombre, id) FROM stdin;
e5366df0-295e-426a-9e01-6c3fc2b15121	cabana	Cabaña	7e08e007-0321-46d7-8401-dfba1bbec16a
e5366df0-295e-426a-9e01-6c3fc2b15121	casa	Casa	a7570113-3ee6-42ce-8c93-b868c23b41de
e5366df0-295e-426a-9e01-6c3fc2b15121	departamento	Departamento	c35251e2-5325-477e-ab28-3f1cc33a75e3
e5366df0-295e-426a-9e01-6c3fc2b15121	hosteria	Hostería	89ea77e5-afda-4a19-ac3a-0c05ab691a23
e5366df0-295e-426a-9e01-6c3fc2b15121	hotel	Hotel	1e537509-f1d1-4693-9444-47ec656f7401
e5366df0-295e-426a-9e01-6c3fc2b15121	bungalow	Bungalow	24802f05-bd46-476f-9ff0-895dfe34294b
2a0cfafc-cda4-435f-945c-5f07010fc118	salon_eventos	Salón	a502f2e7-da9d-4026-9712-5702113d8a71
2a0cfafc-cda4-435f-945c-5f07010fc118	quincho_eventos	Quincho	41db3c50-505a-4a46-9ec7-14e200e7bf85
2a0cfafc-cda4-435f-945c-5f07010fc118	aire_libre	Espacio al aire libre	62edb355-c573-4c18-943c-8298142b222d
01f97704-06af-499b-bbc0-ded5f81a541e	cabalgata	Cabalgata	eebfe728-4339-440b-83c1-52a742d4220e
01f97704-06af-499b-bbc0-ded5f81a541e	trekking	Trekking	601cc43d-079e-48d4-bd33-977e7a6db948
01f97704-06af-499b-bbc0-ded5f81a541e	visita_bodega	Visita a bodega	4e1c62ea-7c7d-453f-9c11-abbf0d644ec7
01f97704-06af-499b-bbc0-ded5f81a541e	paseo_guiado	Paseo guiado	34da2aeb-0fcf-49b2-a0d4-4da2be657b63
01f97704-06af-499b-bbc0-ded5f81a541e	aventura	Aventura	607eab9e-02d3-4921-b071-10ebd4ac6500
309f8bcf-5a35-47ab-a09f-616c34763793	traslado_aeropuerto	Aeropuerto y terminal	891accf6-1e15-46b2-a096-afd5806c4f57
309f8bcf-5a35-47ab-a09f-616c34763793	traslado_regional	Entre localidades	ae0fbcf8-3685-4530-ab86-8c96ef011f07
309f8bcf-5a35-47ab-a09f-616c34763793	traslado_urbano	Dentro de la ciudad	4d79869f-a6bf-4883-a4bc-935f2d6eb85c
\.


--
-- Data for Name: tarifa; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.tarifa (unidad_id, nombre, fecha_desde, fecha_hasta, precio_noche, precios_dia_semana, estadia_minima, estadia_maxima, anticipacion_minima_dias, prioridad, id) FROM stdin;
\.


--
-- Data for Name: tarifa_horaria; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.tarifa_horaria (unidad_id, precio_hora, precios_dia_semana, horas_minimas, hora_apertura, hora_cierre, recargo_nocturno_desde, recargo_nocturno_porcentaje, activa, id) FROM stdin;
\.


--
-- Data for Name: tarifa_traslado; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.tarifa_traslado (unidad_id, precio_km, bajada, minimo, radio_km, factor_ruta, velocidad_kmh, recargo_nocturno_desde, recargo_nocturno_hasta, recargo_nocturno_porcentaje, vuelve_a_base, anticipacion_minima_horas, id) FROM stdin;
\.


--
-- Data for Name: tipo_servicio; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.tipo_servicio (codigo, nombre, modo_reserva, activo, id) FROM stdin;
alojamiento	Alojamiento	noches	t	e5366df0-295e-426a-9e01-6c3fc2b15121
excursion	Excursión	turno_cupo	t	01f97704-06af-499b-bbc0-ded5f81a541e
gastronomia	Gastronomía	horario	t	a1641ec0-481b-40f9-8f59-0e6882140181
traslado	Traslado	tramo	t	309f8bcf-5a35-47ab-a09f-616c34763793
salon_eventos	Salón de eventos	horas	t	2a0cfafc-cda4-435f-945c-5f07010fc118
\.


--
-- Data for Name: tramo_traslado; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.tramo_traslado (unidad_id, origen_id, destino_id, precio, por_persona, duracion_minutos, ambos_sentidos, activo, id) FROM stdin;
\.


--
-- Data for Name: turno_excursion; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.turno_excursion (unidad_id, nombre, dias_semana, hora_inicio, duracion_minutos, cupo, desde, hasta, activo, id, creado_en, actualizado_en, minimo_personas, aviso_minimo_horas) FROM stdin;
\.


--
-- Data for Name: unidad; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.unidad (publicacion_id, nombre, capacidad, capacidad_base, activa, cargo_limpieza, cargo_persona_extra, cargo_mascota, descuento_semanal, descuento_mensual, ical_export_token, id, creado_en, actualizado_en, capacidad_sentados, preparacion_minutos, equipaje) FROM stdin;
\.


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.usuario (email, hash_password, google_sub, nombre, apellido, telefono, email_verificado, telefono_verificado, es_viajero, es_prestador, es_operador, activo, id, creado_en, actualizado_en, acepto_terminos_en, version_terminos) FROM stdin;
illanezjorgea@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$a32dioBI3jMcBO8ndWTcbQ$Za65mdZ/rKpD++p8IMZKMOY+qsJcu+JhDo3OIVSX0rg	\N	Jorge	Illanez	\N	t	f	t	f	t	t	57ede3f2-6975-486d-997e-0d1b08ce1b27	2026-11-20 14:38:14.199441+00	2026-11-20 14:38:14.199441+00	2026-11-20 14:38:14.367198+00	\N
virginialauratello@gmail.com	$argon2id$v=19$m=65536,t=3,p=4$99GoSlHv+SfrnpXfL7PGjw$yUScaDTEr1/LSez8wgNlBUTD4wgVIa2+AR8YNvTY+cU	\N	Virginia laura	tello	+5492645408193	t	f	t	t	f	t	feecbaf5-7297-455c-9349-d1ef445a37f2	2026-11-28 10:50:14.517289+00	2026-11-28 10:54:37.579384+00	2026-11-28 10:50:14.894259+00	2026-09
\.


--
-- Data for Name: zona; Type: TABLE DATA; Schema: public; Owner: suite
--

COPY public.zona (localidad_id, nombre, id) FROM stdin;
4d474921-8e18-489c-b537-0a7164b9d7e4	Marquesado	ded07f7c-9508-4d7a-bb06-ebf03e6b5363
4d474921-8e18-489c-b537-0a7164b9d7e4	La Bebida	5f893bd6-d0a3-40e5-919b-2b953a7d8fb0
4d474921-8e18-489c-b537-0a7164b9d7e4	Quebrada de Zonda	70008a43-ecc2-45f6-9b70-e471df8b35a4
4d474921-8e18-489c-b537-0a7164b9d7e4	Meglioli	70da84a5-2c30-42e4-9423-17f2cac23f5a
4d474921-8e18-489c-b537-0a7164b9d7e4	Undiano	5d061120-3729-48c9-a3be-2bfa950b5209
893a1837-21e9-4a8a-b071-6ffa1d41a090	Centro	9a14c7bf-0a55-460b-87cd-b83e4365896e
893a1837-21e9-4a8a-b071-6ffa1d41a090	Desamparados	2eeb05f2-956a-4979-a146-b04002c691fa
893a1837-21e9-4a8a-b071-6ffa1d41a090	Trinidad	6948c175-3302-47cd-900e-c2d4554ae5ac
893a1837-21e9-4a8a-b071-6ffa1d41a090	Concepción	871712c1-2273-47e9-b58a-adbbe928efba
70426ae5-157a-4f56-9002-217e7e01b4c2	Villa Krause	e06b93b6-b12f-4e95-8f79-455583693304
70426ae5-157a-4f56-9002-217e7e01b4c2	Médano de Oro	e5c1fc4c-3c4f-4e43-af6d-356efd0419c1
70426ae5-157a-4f56-9002-217e7e01b4c2	Villa Bolaños	876e9ff1-92b8-40a3-b650-1a2b4ba81fa2
70426ae5-157a-4f56-9002-217e7e01b4c2	Villa Centenario	7b12ef46-05c3-4ae3-93c3-5a607eee94bb
76454ee5-d666-4ae7-b09b-59372a20c211	Villa Santa Lucía	5f4b2153-c3cc-49c2-9df4-2dbf2e029902
76454ee5-d666-4ae7-b09b-59372a20c211	Colonia Sarmiento	fcc95b73-52d0-4b84-a457-88c20895ba19
a2e49770-611c-40f7-a75e-58e95801a11e	Villa Paula	e2196f98-8bb9-40d5-afe8-073a23d2a875
a2e49770-611c-40f7-a75e-58e95801a11e	El Mogote	83729d2a-87dd-4037-8b2a-c7eda715e261
7ec38a8b-5953-4a2f-b132-6ee8d3ac3434	Villa Aberastain	8b7b296a-2acf-41b1-a43b-684736449f03
7ec38a8b-5953-4a2f-b132-6ee8d3ac3434	Carpintería	90072034-23b5-4106-b23f-c04f0f9dea58
7ec38a8b-5953-4a2f-b132-6ee8d3ac3434	La Rinconada	ad735129-d806-40c9-8069-4a648bfc47b4
ff6ad213-3ed6-45f4-ab3a-8a2077b61589	Campo Afuera	3d9c28d1-9bc9-4ba0-b9c1-5d8e2613b9b5
ff6ad213-3ed6-45f4-ab3a-8a2077b61589	Las Lomitas	02232081-6c19-4816-8c2b-1206afa5e2d3
29252016-0527-4a46-9a1c-9decda5b2e21	Vallecito	88699bba-9b76-469f-b0c6-e9eb6878ea37
29252016-0527-4a46-9a1c-9decda5b2e21	Bermejo	89c57812-ad38-4c0a-8114-dfd92f2f40e4
29252016-0527-4a46-9a1c-9decda5b2e21	Pie de Palo	2536c4e4-7d6c-47f3-9bb7-48d2f1f9df7e
493559b0-0e05-4b0e-8e2c-4ff04250f236	Villa Santa Rosa	e95d28ba-a76d-4eaa-b566-12198913457a
8695c4e4-d4fb-4c5a-af47-4e7ef6f996b5	Villa El Salvador	52c0ec20-330a-4b0c-a0ce-a83a10335900
827222ce-fc7e-4bda-b67c-193e87a2fdae	Villa Dominguito	6879519a-5bcd-4f84-9b29-e7b3360472ee
ac635798-6f76-47f0-8cef-251c0fc07595	Santa Rosa	299ec4ea-3471-402d-a115-21072d7fdfbf
3036738b-ca40-4ec9-a3ff-7d0b36ce42c7	Media Agua	4e46584c-5bc9-4868-91fe-8bdd205580e8
3036738b-ca40-4ec9-a3ff-7d0b36ce42c7	Cienaguita	69407be7-1cfe-4035-8c68-66c85c66126d
3036738b-ca40-4ec9-a3ff-7d0b36ce42c7	Los Berros	62708e15-6f7e-4a3d-9b4b-ded781a45e9f
07763fc9-0c72-427c-ac79-eba86b50d1ac	Villa Basilio Nievas	d0ec08f7-c06c-4929-9669-999521d6935a
07763fc9-0c72-427c-ac79-eba86b50d1ac	Quebrada de Zonda	2a8a6e85-1f9f-401c-8478-b636eab69655
a67ba024-b2bb-4ad5-83d3-374e54721d0b	Villa Ibáñez	024009f9-2158-492b-9a3e-22e840f789b5
a67ba024-b2bb-4ad5-83d3-374e54721d0b	Dique de Ullum	57e23c3f-a110-42c2-9961-4ebfe1eccd00
a67ba024-b2bb-4ad5-83d3-374e54721d0b	Las Tapias	072c3360-1f33-46ca-99e7-9674c1f47d5d
2f3e049a-e572-4491-a7a0-053f843f1fae	Barreal	b2653f74-a047-4356-aa40-35a7cfcc13e1
2f3e049a-e572-4491-a7a0-053f843f1fae	Tamberías	2cd5ab04-a1f3-4d68-b72e-942530464c87
2f3e049a-e572-4491-a7a0-053f843f1fae	Villa Calingasta	df0fd1d0-e9f3-4bab-af81-b4e84107d0e3
2f3e049a-e572-4491-a7a0-053f843f1fae	Sorocayense	9dc7bb51-c2c1-4927-ada4-08d4899e277a
2aa010ef-d042-4969-93fa-36f0ea1924ca	Rodeo	404a9e4e-bd01-4dd9-9de4-e9e1c533c169
2aa010ef-d042-4969-93fa-36f0ea1924ca	Las Flores	eceddc0f-fd38-4f27-888c-3f2a9baa958b
2aa010ef-d042-4969-93fa-36f0ea1924ca	Pismanta	500ce081-b409-479c-81d3-2eab8f679aec
2aa010ef-d042-4969-93fa-36f0ea1924ca	Bella Vista	865745ee-1cea-4d03-9a94-86289e353794
2aa010ef-d042-4969-93fa-36f0ea1924ca	Angualasto	efc79349-cede-4fc7-9db7-998f5cc32428
1b081dfc-0ea1-41cf-ab99-6a7be32c7571	San Agustín del Valle Fértil	d4c7876b-66c5-4930-a019-c323c2e00f46
1b081dfc-0ea1-41cf-ab99-6a7be32c7571	Usno	6002af32-6018-4e0d-80bf-0c0b01eff153
1b081dfc-0ea1-41cf-ab99-6a7be32c7571	Chucuma	c2886751-1c55-481a-8f7e-8949810d6584
1b081dfc-0ea1-41cf-ab99-6a7be32c7571	Astica	5f1f7e76-c679-466d-b7fa-fbb80b70dc6c
180a42ae-c292-4c69-b4aa-4e7cfc02589b	San José de Jáchal	00d6f150-6916-4d0a-9dc5-d80f2e50b540
180a42ae-c292-4c69-b4aa-4e7cfc02589b	Huaco	e3741aa1-ce52-4bdc-b034-1d56fca11404
180a42ae-c292-4c69-b4aa-4e7cfc02589b	El Médano	ec9c076e-e0c6-47b3-8a8b-0b6d6170f333
180a42ae-c292-4c69-b4aa-4e7cfc02589b	Pampa Vieja	a6eab1c6-35ec-4c35-a4a2-4496c53e606e
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: suite
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: suite
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: suite
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: suite
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: suite
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: suite
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: suite
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: bloqueo_fecha ex_bloqueo_fecha_sin_superposicion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT ex_bloqueo_fecha_sin_superposicion EXCLUDE USING gist (unidad_id WITH =, rango WITH &&) WHERE (activo);


--
-- Name: bloqueo_horario ex_bloqueo_horario_sin_superposicion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_horario
    ADD CONSTRAINT ex_bloqueo_horario_sin_superposicion EXCLUDE USING gist (unidad_id WITH =, rango WITH &&) WHERE (activo);


--
-- Name: adicional pk_adicional; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.adicional
    ADD CONSTRAINT pk_adicional PRIMARY KEY (id);


--
-- Name: bloqueo_fecha pk_bloqueo_fecha; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT pk_bloqueo_fecha PRIMARY KEY (id);


--
-- Name: bloqueo_horario pk_bloqueo_horario; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_horario
    ADD CONSTRAINT pk_bloqueo_horario PRIMARY KEY (id);


--
-- Name: calendario_externo pk_calendario_externo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.calendario_externo
    ADD CONSTRAINT pk_calendario_externo PRIMARY KEY (id);


--
-- Name: comision_aplicada pk_comision_aplicada; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comision_aplicada
    ADD CONSTRAINT pk_comision_aplicada PRIMARY KEY (id);


--
-- Name: comodidad pk_comodidad; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comodidad
    ADD CONSTRAINT pk_comodidad PRIMARY KEY (id);


--
-- Name: comodidad_tipo_servicio pk_comodidad_tipo_servicio; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comodidad_tipo_servicio
    ADD CONSTRAINT pk_comodidad_tipo_servicio PRIMARY KEY (comodidad_id, tipo_servicio_id);


--
-- Name: cupo_tomado pk_cupo_tomado; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.cupo_tomado
    ADD CONSTRAINT pk_cupo_tomado PRIMARY KEY (id);


--
-- Name: favorito pk_favorito; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.favorito
    ADD CONSTRAINT pk_favorito PRIMARY KEY (id);


--
-- Name: foto pk_foto; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.foto
    ADD CONSTRAINT pk_foto PRIMARY KEY (id);


--
-- Name: franja_horaria pk_franja_horaria; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.franja_horaria
    ADD CONSTRAINT pk_franja_horaria PRIMARY KEY (id);


--
-- Name: item_reserva pk_item_reserva; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.item_reserva
    ADD CONSTRAINT pk_item_reserva PRIMARY KEY (id);


--
-- Name: localidad pk_localidad; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT pk_localidad PRIMARY KEY (id);


--
-- Name: lugar_traslado pk_lugar_traslado; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.lugar_traslado
    ADD CONSTRAINT pk_lugar_traslado PRIMARY KEY (id);


--
-- Name: notificacion pk_notificacion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT pk_notificacion PRIMARY KEY (id);


--
-- Name: notificacion_pago pk_notificacion_mp; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.notificacion_pago
    ADD CONSTRAINT pk_notificacion_mp PRIMARY KEY (id);


--
-- Name: pago pk_pago; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT pk_pago PRIMARY KEY (id);


--
-- Name: politica_cancelacion pk_politica_cancelacion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.politica_cancelacion
    ADD CONSTRAINT pk_politica_cancelacion PRIMARY KEY (id);


--
-- Name: precio_pasajero pk_precio_pasajero; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.precio_pasajero
    ADD CONSTRAINT pk_precio_pasajero PRIMARY KEY (id);


--
-- Name: prestador pk_prestador; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.prestador
    ADD CONSTRAINT pk_prestador PRIMARY KEY (id);


--
-- Name: provincia pk_provincia; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT pk_provincia PRIMARY KEY (id);


--
-- Name: publicacion pk_publicacion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT pk_publicacion PRIMARY KEY (id);


--
-- Name: publicacion_comodidad pk_publicacion_comodidad; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion_comodidad
    ADD CONSTRAINT pk_publicacion_comodidad PRIMARY KEY (publicacion_id, comodidad_id);


--
-- Name: regla_comision pk_regla_comision; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT pk_regla_comision PRIMARY KEY (id);


--
-- Name: regla_comision_historial pk_regla_comision_historial; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision_historial
    ADD CONSTRAINT pk_regla_comision_historial PRIMARY KEY (id);


--
-- Name: resena pk_resena; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.resena
    ADD CONSTRAINT pk_resena PRIMARY KEY (id);


--
-- Name: reserva pk_reserva; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT pk_reserva PRIMARY KEY (id);


--
-- Name: reserva_externa pk_reserva_externa; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva_externa
    ADD CONSTRAINT pk_reserva_externa PRIMARY KEY (id);


--
-- Name: salida_excursion pk_salida_excursion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.salida_excursion
    ADD CONSTRAINT pk_salida_excursion PRIMARY KEY (id);


--
-- Name: subtipo_servicio pk_subtipo_servicio; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.subtipo_servicio
    ADD CONSTRAINT pk_subtipo_servicio PRIMARY KEY (id);


--
-- Name: tarifa pk_tarifa; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa
    ADD CONSTRAINT pk_tarifa PRIMARY KEY (id);


--
-- Name: tarifa_horaria pk_tarifa_horaria; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_horaria
    ADD CONSTRAINT pk_tarifa_horaria PRIMARY KEY (id);


--
-- Name: tarifa_traslado pk_tarifa_traslado; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_traslado
    ADD CONSTRAINT pk_tarifa_traslado PRIMARY KEY (id);


--
-- Name: tipo_servicio pk_tipo_servicio; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tipo_servicio
    ADD CONSTRAINT pk_tipo_servicio PRIMARY KEY (id);


--
-- Name: tramo_traslado pk_tramo_traslado; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tramo_traslado
    ADD CONSTRAINT pk_tramo_traslado PRIMARY KEY (id);


--
-- Name: turno_excursion pk_turno_excursion; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.turno_excursion
    ADD CONSTRAINT pk_turno_excursion PRIMARY KEY (id);


--
-- Name: unidad pk_unidad; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.unidad
    ADD CONSTRAINT pk_unidad PRIMARY KEY (id);


--
-- Name: usuario pk_usuario; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT pk_usuario PRIMARY KEY (id);


--
-- Name: zona pk_zona; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.zona
    ADD CONSTRAINT pk_zona PRIMARY KEY (id);


--
-- Name: comision_aplicada uq_comision_aplicada_item_reserva_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comision_aplicada
    ADD CONSTRAINT uq_comision_aplicada_item_reserva_id UNIQUE (item_reserva_id);


--
-- Name: comodidad uq_comodidad_codigo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comodidad
    ADD CONSTRAINT uq_comodidad_codigo UNIQUE (codigo);


--
-- Name: favorito uq_favorito_usuario_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.favorito
    ADD CONSTRAINT uq_favorito_usuario_id UNIQUE (usuario_id, publicacion_id);


--
-- Name: localidad uq_localidad_provincia_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT uq_localidad_provincia_id UNIQUE (provincia_id, slug);


--
-- Name: lugar_traslado uq_lugar_traslado_nombre; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.lugar_traslado
    ADD CONSTRAINT uq_lugar_traslado_nombre UNIQUE (publicacion_id, nombre);


--
-- Name: notificacion_pago uq_notificacion_pago_pasarela; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.notificacion_pago
    ADD CONSTRAINT uq_notificacion_pago_pasarela UNIQUE (pasarela, id_externo);


--
-- Name: pago uq_pago_pasarela; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT uq_pago_pasarela UNIQUE (pasarela, id_externo);


--
-- Name: politica_cancelacion uq_politica_cancelacion_codigo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.politica_cancelacion
    ADD CONSTRAINT uq_politica_cancelacion_codigo UNIQUE (codigo);


--
-- Name: prestador uq_prestador_cuit; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.prestador
    ADD CONSTRAINT uq_prestador_cuit UNIQUE (cuit);


--
-- Name: prestador uq_prestador_usuario_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.prestador
    ADD CONSTRAINT uq_prestador_usuario_id UNIQUE (usuario_id);


--
-- Name: provincia uq_provincia_nombre; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT uq_provincia_nombre UNIQUE (nombre);


--
-- Name: provincia uq_provincia_slug; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT uq_provincia_slug UNIQUE (slug);


--
-- Name: publicacion uq_publicacion_slug; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT uq_publicacion_slug UNIQUE (slug);


--
-- Name: resena uq_resena_reserva_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.resena
    ADD CONSTRAINT uq_resena_reserva_id UNIQUE (reserva_id);


--
-- Name: reserva uq_reserva_codigo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT uq_reserva_codigo UNIQUE (codigo);


--
-- Name: reserva_externa uq_reserva_externa_huella; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva_externa
    ADD CONSTRAINT uq_reserva_externa_huella UNIQUE (prestador_id, huella);


--
-- Name: salida_excursion uq_salida_excursion_turno_fecha; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.salida_excursion
    ADD CONSTRAINT uq_salida_excursion_turno_fecha UNIQUE (turno_id, fecha);


--
-- Name: subtipo_servicio uq_subtipo_servicio_codigo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.subtipo_servicio
    ADD CONSTRAINT uq_subtipo_servicio_codigo UNIQUE (codigo);


--
-- Name: tarifa_horaria uq_tarifa_horaria_unidad_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_horaria
    ADD CONSTRAINT uq_tarifa_horaria_unidad_id UNIQUE (unidad_id);


--
-- Name: tarifa_traslado uq_tarifa_traslado_unidad_id; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_traslado
    ADD CONSTRAINT uq_tarifa_traslado_unidad_id UNIQUE (unidad_id);


--
-- Name: tipo_servicio uq_tipo_servicio_codigo; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tipo_servicio
    ADD CONSTRAINT uq_tipo_servicio_codigo UNIQUE (codigo);


--
-- Name: tramo_traslado uq_tramo_traslado; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tramo_traslado
    ADD CONSTRAINT uq_tramo_traslado UNIQUE (unidad_id, origen_id, destino_id);


--
-- Name: unidad uq_unidad_ical_export_token; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.unidad
    ADD CONSTRAINT uq_unidad_ical_export_token UNIQUE (ical_export_token);


--
-- Name: usuario uq_usuario_google_sub; Type: CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT uq_usuario_google_sub UNIQUE (google_sub);


--
-- Name: ix_adicional_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_adicional_unidad_id ON public.adicional USING btree (unidad_id);


--
-- Name: ix_bloqueo_fecha_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_bloqueo_fecha_unidad_id ON public.bloqueo_fecha USING btree (unidad_id);


--
-- Name: ix_bloqueo_fecha_vence; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_bloqueo_fecha_vence ON public.bloqueo_fecha USING btree (vence_en) WHERE (vence_en IS NOT NULL);


--
-- Name: ix_bloqueo_horario_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_bloqueo_horario_unidad_id ON public.bloqueo_horario USING btree (unidad_id);


--
-- Name: ix_bloqueo_horario_vence; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_bloqueo_horario_vence ON public.bloqueo_horario USING btree (vence_en) WHERE (vence_en IS NOT NULL);


--
-- Name: ix_calendario_externo_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_calendario_externo_unidad_id ON public.calendario_externo USING btree (unidad_id);


--
-- Name: ix_cupo_tomado_salida_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_cupo_tomado_salida_id ON public.cupo_tomado USING btree (salida_id);


--
-- Name: ix_cupo_tomado_vence; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_cupo_tomado_vence ON public.cupo_tomado USING btree (vence_en) WHERE activo;


--
-- Name: ix_favorito_publicacion_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_favorito_publicacion_id ON public.favorito USING btree (publicacion_id);


--
-- Name: ix_favorito_usuario_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_favorito_usuario_id ON public.favorito USING btree (usuario_id);


--
-- Name: ix_foto_publicacion_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_foto_publicacion_id ON public.foto USING btree (publicacion_id);


--
-- Name: ix_franja_horaria_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_franja_horaria_unidad_id ON public.franja_horaria USING btree (unidad_id);


--
-- Name: ix_item_reserva_prestador_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_item_reserva_prestador_id ON public.item_reserva USING btree (prestador_id);


--
-- Name: ix_item_reserva_reserva_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_item_reserva_reserva_id ON public.item_reserva USING btree (reserva_id);


--
-- Name: ix_item_reserva_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_item_reserva_unidad_id ON public.item_reserva USING btree (unidad_id);


--
-- Name: ix_localidad_provincia_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_localidad_provincia_id ON public.localidad USING btree (provincia_id);


--
-- Name: ix_localidad_ubicacion; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_localidad_ubicacion ON public.localidad USING gist (ubicacion);


--
-- Name: ix_lugar_traslado_publicacion_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_lugar_traslado_publicacion_id ON public.lugar_traslado USING btree (publicacion_id);


--
-- Name: ix_notificacion_evento; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_notificacion_evento ON public.notificacion USING btree (evento);


--
-- Name: ix_notificacion_pago_pasarela; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_notificacion_pago_pasarela ON public.notificacion_pago USING btree (pasarela);


--
-- Name: ix_notificacion_pendientes; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_notificacion_pendientes ON public.notificacion USING btree (estado, creado_en);


--
-- Name: ix_notificacion_reserva_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_notificacion_reserva_id ON public.notificacion USING btree (reserva_id);


--
-- Name: ix_notificacion_usuario_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_notificacion_usuario_id ON public.notificacion USING btree (usuario_id);


--
-- Name: ix_pago_reserva_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_pago_reserva_id ON public.pago USING btree (reserva_id);


--
-- Name: ix_precio_pasajero_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_precio_pasajero_unidad_id ON public.precio_pasajero USING btree (unidad_id);


--
-- Name: ix_publicacion_es_demo; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_publicacion_es_demo ON public.publicacion USING btree (es_demo);


--
-- Name: ix_publicacion_estado; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_publicacion_estado ON public.publicacion USING btree (estado);


--
-- Name: ix_publicacion_localidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_publicacion_localidad_id ON public.publicacion USING btree (localidad_id);


--
-- Name: ix_publicacion_prestador_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_publicacion_prestador_id ON public.publicacion USING btree (prestador_id);


--
-- Name: ix_publicacion_ubicacion; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_publicacion_ubicacion ON public.publicacion USING gist (ubicacion);


--
-- Name: ix_regla_comision_historial_regla_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_regla_comision_historial_regla_id ON public.regla_comision_historial USING btree (regla_id);


--
-- Name: ix_resena_publicacion_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_resena_publicacion_id ON public.resena USING btree (publicacion_id);


--
-- Name: ix_reserva_estado; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_reserva_estado ON public.reserva USING btree (estado);


--
-- Name: ix_reserva_externa_prestador_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_reserva_externa_prestador_id ON public.reserva_externa USING btree (prestador_id);


--
-- Name: ix_reserva_externa_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_reserva_externa_unidad_id ON public.reserva_externa USING btree (unidad_id);


--
-- Name: ix_reserva_usuario_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_reserva_usuario_id ON public.reserva USING btree (usuario_id);


--
-- Name: ix_salida_excursion_unidad_fecha; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_salida_excursion_unidad_fecha ON public.salida_excursion USING btree (unidad_id, fecha);


--
-- Name: ix_subtipo_servicio_tipo_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_subtipo_servicio_tipo_id ON public.subtipo_servicio USING btree (tipo_id);


--
-- Name: ix_tarifa_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_tarifa_unidad_id ON public.tarifa USING btree (unidad_id);


--
-- Name: ix_tramo_traslado_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_tramo_traslado_unidad_id ON public.tramo_traslado USING btree (unidad_id);


--
-- Name: ix_turno_excursion_unidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_turno_excursion_unidad_id ON public.turno_excursion USING btree (unidad_id);


--
-- Name: ix_unidad_publicacion_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_unidad_publicacion_id ON public.unidad USING btree (publicacion_id);


--
-- Name: ix_usuario_email; Type: INDEX; Schema: public; Owner: suite
--

CREATE UNIQUE INDEX ix_usuario_email ON public.usuario USING btree (email);


--
-- Name: ix_zona_localidad_id; Type: INDEX; Schema: public; Owner: suite
--

CREATE INDEX ix_zona_localidad_id ON public.zona USING btree (localidad_id);


--
-- Name: uq_regla_comision_default; Type: INDEX; Schema: public; Owner: suite
--

CREATE UNIQUE INDEX uq_regla_comision_default ON public.regla_comision USING btree (es_default) WHERE es_default;


--
-- Name: adicional fk_adicional_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.adicional
    ADD CONSTRAINT fk_adicional_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: bloqueo_fecha fk_bloqueo_fecha_calendario_externo_id_calendario_externo; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT fk_bloqueo_fecha_calendario_externo_id_calendario_externo FOREIGN KEY (calendario_externo_id) REFERENCES public.calendario_externo(id) ON DELETE CASCADE;


--
-- Name: bloqueo_fecha fk_bloqueo_fecha_item_reserva_id_item_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT fk_bloqueo_fecha_item_reserva_id_item_reserva FOREIGN KEY (item_reserva_id) REFERENCES public.item_reserva(id);


--
-- Name: bloqueo_fecha fk_bloqueo_fecha_reserva_externa_id_reserva_externa; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT fk_bloqueo_fecha_reserva_externa_id_reserva_externa FOREIGN KEY (reserva_externa_id) REFERENCES public.reserva_externa(id) ON DELETE CASCADE;


--
-- Name: bloqueo_fecha fk_bloqueo_fecha_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_fecha
    ADD CONSTRAINT fk_bloqueo_fecha_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: bloqueo_horario fk_bloqueo_horario_item_reserva_id_item_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_horario
    ADD CONSTRAINT fk_bloqueo_horario_item_reserva_id_item_reserva FOREIGN KEY (item_reserva_id) REFERENCES public.item_reserva(id);


--
-- Name: bloqueo_horario fk_bloqueo_horario_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.bloqueo_horario
    ADD CONSTRAINT fk_bloqueo_horario_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: calendario_externo fk_calendario_externo_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.calendario_externo
    ADD CONSTRAINT fk_calendario_externo_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: comision_aplicada fk_comision_aplicada_item_reserva_id_item_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comision_aplicada
    ADD CONSTRAINT fk_comision_aplicada_item_reserva_id_item_reserva FOREIGN KEY (item_reserva_id) REFERENCES public.item_reserva(id) ON DELETE CASCADE;


--
-- Name: comision_aplicada fk_comision_aplicada_regla_id_regla_comision; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comision_aplicada
    ADD CONSTRAINT fk_comision_aplicada_regla_id_regla_comision FOREIGN KEY (regla_id) REFERENCES public.regla_comision(id);


--
-- Name: comodidad_tipo_servicio fk_comodidad_tipo_servicio_comodidad_id_comodidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comodidad_tipo_servicio
    ADD CONSTRAINT fk_comodidad_tipo_servicio_comodidad_id_comodidad FOREIGN KEY (comodidad_id) REFERENCES public.comodidad(id) ON DELETE CASCADE;


--
-- Name: comodidad_tipo_servicio fk_comodidad_tipo_servicio_tipo_servicio_id_tipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.comodidad_tipo_servicio
    ADD CONSTRAINT fk_comodidad_tipo_servicio_tipo_servicio_id_tipo_servicio FOREIGN KEY (tipo_servicio_id) REFERENCES public.tipo_servicio(id) ON DELETE CASCADE;


--
-- Name: cupo_tomado fk_cupo_tomado_item_reserva_id_item_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.cupo_tomado
    ADD CONSTRAINT fk_cupo_tomado_item_reserva_id_item_reserva FOREIGN KEY (item_reserva_id) REFERENCES public.item_reserva(id);


--
-- Name: cupo_tomado fk_cupo_tomado_salida_id_salida_excursion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.cupo_tomado
    ADD CONSTRAINT fk_cupo_tomado_salida_id_salida_excursion FOREIGN KEY (salida_id) REFERENCES public.salida_excursion(id);


--
-- Name: favorito fk_favorito_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.favorito
    ADD CONSTRAINT fk_favorito_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id) ON DELETE CASCADE;


--
-- Name: favorito fk_favorito_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.favorito
    ADD CONSTRAINT fk_favorito_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: foto fk_foto_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.foto
    ADD CONSTRAINT fk_foto_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id) ON DELETE CASCADE;


--
-- Name: franja_horaria fk_franja_horaria_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.franja_horaria
    ADD CONSTRAINT fk_franja_horaria_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: item_reserva fk_item_reserva_prestador_id_prestador; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.item_reserva
    ADD CONSTRAINT fk_item_reserva_prestador_id_prestador FOREIGN KEY (prestador_id) REFERENCES public.prestador(id);


--
-- Name: item_reserva fk_item_reserva_reserva_id_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.item_reserva
    ADD CONSTRAINT fk_item_reserva_reserva_id_reserva FOREIGN KEY (reserva_id) REFERENCES public.reserva(id) ON DELETE CASCADE;


--
-- Name: item_reserva fk_item_reserva_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.item_reserva
    ADD CONSTRAINT fk_item_reserva_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: localidad fk_localidad_provincia_id_provincia; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT fk_localidad_provincia_id_provincia FOREIGN KEY (provincia_id) REFERENCES public.provincia(id);


--
-- Name: lugar_traslado fk_lugar_traslado_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.lugar_traslado
    ADD CONSTRAINT fk_lugar_traslado_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id);


--
-- Name: notificacion fk_notificacion_reserva_id_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT fk_notificacion_reserva_id_reserva FOREIGN KEY (reserva_id) REFERENCES public.reserva(id);


--
-- Name: notificacion fk_notificacion_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT fk_notificacion_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: pago fk_pago_reserva_id_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT fk_pago_reserva_id_reserva FOREIGN KEY (reserva_id) REFERENCES public.reserva(id);


--
-- Name: precio_pasajero fk_precio_pasajero_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.precio_pasajero
    ADD CONSTRAINT fk_precio_pasajero_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: prestador fk_prestador_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.prestador
    ADD CONSTRAINT fk_prestador_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: publicacion_comodidad fk_publicacion_comodidad_comodidad_id_comodidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion_comodidad
    ADD CONSTRAINT fk_publicacion_comodidad_comodidad_id_comodidad FOREIGN KEY (comodidad_id) REFERENCES public.comodidad(id);


--
-- Name: publicacion_comodidad fk_publicacion_comodidad_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion_comodidad
    ADD CONSTRAINT fk_publicacion_comodidad_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id) ON DELETE CASCADE;


--
-- Name: publicacion fk_publicacion_localidad_id_localidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_localidad_id_localidad FOREIGN KEY (localidad_id) REFERENCES public.localidad(id);


--
-- Name: publicacion fk_publicacion_politica_cancelacion_id_politica_cancelacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_politica_cancelacion_id_politica_cancelacion FOREIGN KEY (politica_cancelacion_id) REFERENCES public.politica_cancelacion(id);


--
-- Name: publicacion fk_publicacion_prestador_id_prestador; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_prestador_id_prestador FOREIGN KEY (prestador_id) REFERENCES public.prestador(id);


--
-- Name: publicacion fk_publicacion_subtipo_servicio_id_subtipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_subtipo_servicio_id_subtipo_servicio FOREIGN KEY (subtipo_servicio_id) REFERENCES public.subtipo_servicio(id);


--
-- Name: publicacion fk_publicacion_tipo_servicio_id_tipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_tipo_servicio_id_tipo_servicio FOREIGN KEY (tipo_servicio_id) REFERENCES public.tipo_servicio(id);


--
-- Name: publicacion fk_publicacion_zona_id_zona; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_zona_id_zona FOREIGN KEY (zona_id) REFERENCES public.zona(id);


--
-- Name: regla_comision fk_regla_comision_creado_por_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_creado_por_id_usuario FOREIGN KEY (creado_por_id) REFERENCES public.usuario(id);


--
-- Name: regla_comision_historial fk_regla_comision_historial_regla_id_regla_comision; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision_historial
    ADD CONSTRAINT fk_regla_comision_historial_regla_id_regla_comision FOREIGN KEY (regla_id) REFERENCES public.regla_comision(id);


--
-- Name: regla_comision_historial fk_regla_comision_historial_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision_historial
    ADD CONSTRAINT fk_regla_comision_historial_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: regla_comision fk_regla_comision_localidad_id_localidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_localidad_id_localidad FOREIGN KEY (localidad_id) REFERENCES public.localidad(id);


--
-- Name: regla_comision fk_regla_comision_prestador_id_prestador; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_prestador_id_prestador FOREIGN KEY (prestador_id) REFERENCES public.prestador(id);


--
-- Name: regla_comision fk_regla_comision_provincia_id_provincia; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_provincia_id_provincia FOREIGN KEY (provincia_id) REFERENCES public.provincia(id);


--
-- Name: regla_comision fk_regla_comision_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id);


--
-- Name: regla_comision fk_regla_comision_subtipo_servicio_id_subtipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_subtipo_servicio_id_subtipo_servicio FOREIGN KEY (subtipo_servicio_id) REFERENCES public.subtipo_servicio(id);


--
-- Name: regla_comision fk_regla_comision_tipo_servicio_id_tipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_tipo_servicio_id_tipo_servicio FOREIGN KEY (tipo_servicio_id) REFERENCES public.tipo_servicio(id);


--
-- Name: regla_comision fk_regla_comision_zona_id_zona; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.regla_comision
    ADD CONSTRAINT fk_regla_comision_zona_id_zona FOREIGN KEY (zona_id) REFERENCES public.zona(id);


--
-- Name: resena fk_resena_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.resena
    ADD CONSTRAINT fk_resena_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id);


--
-- Name: resena fk_resena_reserva_id_reserva; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.resena
    ADD CONSTRAINT fk_resena_reserva_id_reserva FOREIGN KEY (reserva_id) REFERENCES public.reserva(id);


--
-- Name: resena fk_resena_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.resena
    ADD CONSTRAINT fk_resena_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: reserva_externa fk_reserva_externa_prestador_id_prestador; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva_externa
    ADD CONSTRAINT fk_reserva_externa_prestador_id_prestador FOREIGN KEY (prestador_id) REFERENCES public.prestador(id);


--
-- Name: reserva_externa fk_reserva_externa_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva_externa
    ADD CONSTRAINT fk_reserva_externa_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: reserva fk_reserva_usuario_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT fk_reserva_usuario_id_usuario FOREIGN KEY (usuario_id) REFERENCES public.usuario(id);


--
-- Name: salida_excursion fk_salida_excursion_turno_id_turno_excursion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.salida_excursion
    ADD CONSTRAINT fk_salida_excursion_turno_id_turno_excursion FOREIGN KEY (turno_id) REFERENCES public.turno_excursion(id);


--
-- Name: salida_excursion fk_salida_excursion_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.salida_excursion
    ADD CONSTRAINT fk_salida_excursion_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: subtipo_servicio fk_subtipo_servicio_tipo_id_tipo_servicio; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.subtipo_servicio
    ADD CONSTRAINT fk_subtipo_servicio_tipo_id_tipo_servicio FOREIGN KEY (tipo_id) REFERENCES public.tipo_servicio(id);


--
-- Name: tarifa_horaria fk_tarifa_horaria_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_horaria
    ADD CONSTRAINT fk_tarifa_horaria_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: tarifa_traslado fk_tarifa_traslado_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa_traslado
    ADD CONSTRAINT fk_tarifa_traslado_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: tarifa fk_tarifa_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tarifa
    ADD CONSTRAINT fk_tarifa_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: tramo_traslado fk_tramo_traslado_destino_id_lugar_traslado; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tramo_traslado
    ADD CONSTRAINT fk_tramo_traslado_destino_id_lugar_traslado FOREIGN KEY (destino_id) REFERENCES public.lugar_traslado(id);


--
-- Name: tramo_traslado fk_tramo_traslado_origen_id_lugar_traslado; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tramo_traslado
    ADD CONSTRAINT fk_tramo_traslado_origen_id_lugar_traslado FOREIGN KEY (origen_id) REFERENCES public.lugar_traslado(id);


--
-- Name: tramo_traslado fk_tramo_traslado_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.tramo_traslado
    ADD CONSTRAINT fk_tramo_traslado_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: turno_excursion fk_turno_excursion_unidad_id_unidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.turno_excursion
    ADD CONSTRAINT fk_turno_excursion_unidad_id_unidad FOREIGN KEY (unidad_id) REFERENCES public.unidad(id);


--
-- Name: unidad fk_unidad_publicacion_id_publicacion; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.unidad
    ADD CONSTRAINT fk_unidad_publicacion_id_publicacion FOREIGN KEY (publicacion_id) REFERENCES public.publicacion(id);


--
-- Name: zona fk_zona_localidad_id_localidad; Type: FK CONSTRAINT; Schema: public; Owner: suite
--

ALTER TABLE ONLY public.zona
    ADD CONSTRAINT fk_zona_localidad_id_localidad FOREIGN KEY (localidad_id) REFERENCES public.localidad(id);


--
-- PostgreSQL database dump complete
--

\unrestrict TcwtMDnIELzGLSZG0NDA2BD8cOxRmq6f8DFfi5iLAFcvjovaiRkW86nZYBG0ojV

